import streamlit as st
import pandas as pd
import numpy as np
import joblib
from xgboost import XGBRegressor
from sklearn.preprocessing import LabelEncoder
from twilio.rest import Client
account_sid = " "# your account sid 
auth_token = " " # your auth  token
verify_sid = " "# your verify sid

def send_otp(phone):
    try:
        client = Client(account_sid, auth_token) 
        client.verify.v2.services(verify_sid).verifications.create(to=phone, channel='sms') 
        return True 
    except Exception as e: print("OTP Error:", e) 
    return False

def check_otp(phone, code):
    try:
        client = Client(account_sid, auth_token) 
        result = client.verify.v2.services(verify_sid).verification_checks.create(to=phone, code=code) 
        return result.status == 'approved' 
    except Exception as e: print("OTP Check Error:", e) 
    return False

# --- Twilio SMS Function ---
def send_sms(to_number, message):
    account_sid = " "# your account sid
    auth_token = " " # your auth  token
    from_number = " "  # your Twilio phone number

    try:
        client = Client(account_sid, auth_token)
        message = client.messages.create(
            body=message,
            from_=from_number,
            to=to_number
        )
        print("✅ SMS SID:", message.sid)
        return True

    except Exception as e:
        print("❌ SMS Error:", e)
        return False

# Load model and dataset
model = joblib.load("xgb_crop_model1.pkl")
df_raw = pd.read_excel("crop_price.xlsx")
df_raw = df_raw.dropna(subset=["MSP"])
df_raw["YEAR_NUMERIC"] = df_raw["YEAR"].apply(lambda x: int(str(x).split("-")[0]))

# Label encoders
le_crop = LabelEncoder()
le_variety = LabelEncoder()
le_type = LabelEncoder()

le_crop.fit(df_raw["COMMODITY"])
le_variety.fit(df_raw["VARIETY"])
le_type.fit(df_raw["CROP_TYPE"])

# Accuracy score
df_encoded = df_raw.copy()
df_encoded["COMMODITY"] = le_crop.transform(df_encoded["COMMODITY"])
df_encoded["VARIETY"] = le_variety.transform(df_encoded["VARIETY"])
df_encoded["CROP_TYPE"] = le_type.transform(df_encoded["CROP_TYPE"])

X = df_encoded[["COMMODITY", "VARIETY", "CROP_TYPE", "YEAR_NUMERIC"]]
y = df_raw["MSP"]
r2 = model.score(X, y)

# --- Streamlit UI ---
st.title("🌾 Crop MSP Prediction 🌾")
st.info(f"📈 Model Accuracy (R² Score): {r2:.2%}")

selected_type = st.selectbox("Step 1: Select Crop Type", sorted(df_raw["CROP_TYPE"].unique()))
filtered_df_type = df_raw[df_raw["CROP_TYPE"] == selected_type]

selected_crop = st.selectbox("Step 2: Select Crop", sorted(filtered_df_type["COMMODITY"].unique()))
filtered_df_crop = filtered_df_type[filtered_df_type["COMMODITY"] == selected_crop]

selected_variety = st.selectbox("Step 3: Select Variety", sorted(filtered_df_crop["VARIETY"].unique()))
year = st.number_input("Step 4: Enter Year", min_value=2000, max_value=2035, value=2023)

# Initialize state
if "prediction" not in st.session_state:
    st.session_state.prediction = None
if "phone_number" not in st.session_state:
    st.session_state.phone_number = ""

# Predict button
if st.button("Predict MSP 💰"):
    crop_encoded = le_crop.transform([selected_crop])[0]
    variety_encoded = le_variety.transform([selected_variety])[0]
    type_encoded = le_type.transform([selected_type])[0]

    input_data = np.array([[crop_encoded, variety_encoded, type_encoded, year]])
    prediction = model.predict(input_data)[0]
    st.session_state.prediction = prediction

    match = df_raw[
        (df_raw["COMMODITY"] == selected_crop) &
        (df_raw["VARIETY"] == selected_variety) &
        (df_raw["CROP_TYPE"] == selected_type) &
        (df_raw["YEAR"].str.startswith(str(year)))
    ]

    if not match.empty:
        actual_msp = match.iloc[0]["MSP"]
        error = abs(actual_msp - prediction)
        percent_error = (error / actual_msp) * 100
        accuracy = 100 - percent_error

        st.success(f"🌟 Predicted MSP: ₹{prediction:.2f}")
        st.info(f"✅ Actual MSP: ₹{actual_msp:.2f}")
        st.info(f"🎯 Prediction Accuracy: {accuracy:.2f}%")
    else:
        st.success(f"🌟 Predicted MSP: ₹{prediction:.2f}")
        st.warning("⚠️ Actual MSP not available for comparison.")
if st.session_state.prediction is not None:
    # 📱 SMS input (expecting 10-digit mobile only)
    raw_number = st.text_input("📱 Enter farmer's 10-digit mobile number", max_chars=10, key="phone_input")
    phone_number = f"+91{raw_number}" if raw_number.isdigit() and len(raw_number) == 10 else ""   

    # If prediction is available, allow SMS
if st.button("📤 Send OTP"):
    if send_otp(phone_number):
        st.session_state.phone_number = phone_number
        st.success("📨 OTP sent to your mobile number.")
    else:
        st.error("❌ Failed to send OTP.")

if "phone_number" in st.session_state:
    otp = st.text_input("🔐 Enter the OTP you received")

    if st.button("✅ Verify and Send MSP SMS"):
        if check_otp(st.session_state.phone_number, otp):
            message = f"🌾 Predicted MSP for {selected_crop} ({selected_variety}) in {year} is ₹{st.session_state.prediction:.2f}. Plan accordingly."
            if send_sms(st.session_state.phone_number, message):
                st.success("✅ SMS sent successfully!")
            else:
                st.error("❌ Failed to send SMS.")
        else:
            st.warning("❌ Incorrect OTP.")

